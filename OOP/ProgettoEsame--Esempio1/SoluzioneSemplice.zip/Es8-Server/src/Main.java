public class Main {
	@SuppressWarnings("unused")
	public static void main(String[] args) {

		ServerInterface serv = new ServerInterface();
		
	}

}
