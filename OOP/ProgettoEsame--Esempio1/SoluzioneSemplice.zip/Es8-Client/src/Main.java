
public class Main {

	public static void main(String[] args) {
		
		BroadcastChatWindow frame = new BroadcastChatWindow();
		frame.setVisible(true);
		frame.pack();
	}

	
}
